
export interface Mission {
  scenario: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface Feedback {
  isCorrect: boolean;
  explanation: string;
}
