
export const CYBERSECURITY_TOPICS: string[] = [
  'Phishing Emails',
  'Strong Passwords',
  'Two-Factor Authentication (2FA)',
  'Public Wi-Fi Risks',
  'Malware and Ransomware',
  'Social Engineering',
  'Software Updates',
  'Data Backups',
  'Secure Browsing (HTTPS)',
  'Physical Security of Devices'
];
