
import { GoogleGenAI, Type } from "@google/genai";
import type { Mission } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const missionSchema = {
  type: Type.OBJECT,
  properties: {
    scenario: {
      type: Type.STRING,
      description: "A short, engaging, and realistic cybersecurity scenario. Should be around 2-4 sentences."
    },
    question: {
      type: Type.STRING,
      description: "A multiple-choice question based on the scenario."
    },
    options: {
      type: Type.ARRAY,
      description: "An array of 4 strings representing the possible answers. One must be correct.",
      items: { type: Type.STRING }
    },
    correctAnswerIndex: {
      type: Type.INTEGER,
      description: "The 0-based index of the correct answer in the 'options' array."
    },
    explanation: {
      type: Type.STRING,
      description: "A clear explanation of why the correct answer is right and the others are wrong. Should be helpful for learning."
    }
  },
  required: ['scenario', 'question', 'options', 'correctAnswerIndex', 'explanation']
};

export const generateMission = async (topic: string): Promise<Mission> => {
  const prompt = `
    You are a cybersecurity training expert creating gamified learning content.
    Generate a single mission for the topic: "${topic}".
    The mission should be a short, realistic scenario followed by a multiple-choice question to test the user's knowledge.
    Return the content as a single JSON object matching the provided schema. The scenario and explanations should be engaging and easy for a beginner to understand. The incorrect options should be plausible but flawed.
    Ensure the 'options' array has exactly 4 items.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: missionSchema,
        temperature: 0.8,
      },
    });

    const missionJsonString = response.text.trim();
    const missionData: Mission = JSON.parse(missionJsonString);

    // Basic validation
    if (missionData.options.length !== 4 || missionData.correctAnswerIndex < 0 || missionData.correctAnswerIndex > 3) {
        throw new Error("Generated mission data is invalid.");
    }
    
    return missionData;
  } catch (error) {
    console.error("Error generating mission with Gemini:", error);
    throw new Error("Failed to parse or generate mission data from the API.");
  }
};
