
import React from 'react';

interface WelcomeScreenProps {
  onStart: () => void;
}

const CodeLine: React.FC<{ text: string; indent?: number; color?: string }> = ({ text, indent = 0, color = 'text-gray-400' }) => (
    <p className={`${color}`} style={{ paddingLeft: `${indent * 1.5}rem` }}>{text}</p>
);

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  return (
    <div className="w-full max-w-3xl text-center p-4">
      <div className="bg-gray-800/50 backdrop-blur-sm border-2 border-cyan-500 rounded-lg p-8 shadow-2xl shadow-cyan-500/20">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 font-orbitron text-cyan-300 tracking-wider">
          Cyber Sentinel Training
        </h1>
        <p className="text-lg text-gray-300 mb-8">
          Your mission is to defend the digital frontier. Sharpen your skills, identify threats, and become a sentinel of cybersecurity.
        </p>
        <div className="text-left font-mono text-sm bg-black/30 p-6 rounded-md border border-gray-700 my-8">
            <CodeLine text="// Initialize_Training_Protocol.js" color="text-gray-500" />
            <CodeLine text="const trainingModule = new CyberSentinel();" />
            <br />
            <CodeLine text="function startMission(user) {" indent={0} />
            <CodeLine text="if (user.isReady()) {" indent={1} />
            <CodeLine text="trainingModule.initiate();" indent={2} color="text-green-400" />
            <CodeLine text="}" indent={1} />
            <CodeLine text="}" indent={0} />
            <br />
            <CodeLine text="startMission(currentUser);" color="text-yellow-400"/>
        </div>
        <button
          onClick={onStart}
          className="bg-cyan-500 hover:bg-cyan-400 text-gray-900 font-bold py-4 px-10 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/30 text-xl"
        >
          Begin Training
        </button>
      </div>
    </div>
  );
};
