
import React from 'react';

interface ScoreDisplayProps {
  score: number;
  currentMission: number;
  totalMissions: number;
}

export const ScoreDisplay: React.FC<ScoreDisplayProps> = ({ score, currentMission, totalMissions }) => {
  const progressPercentage = (currentMission / totalMissions) * 100;

  return (
    <div className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-lg p-4 mb-6 shadow-lg flex items-center justify-between">
      <div>
        <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-widest font-orbitron">Mission Progress</h2>
        <p className="text-xl text-gray-200">{currentMission} / {totalMissions}</p>
      </div>
      <div className="w-1/2 mx-4">
        <div className="w-full bg-gray-700 rounded-full h-2.5">
            <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${progressPercentage}%`, transition: 'width 0.5s ease-in-out' }}></div>
        </div>
      </div>
      <div className="text-right">
        <h2 className="text-sm font-bold text-green-400 uppercase tracking-widest font-orbitron">Score</h2>
        <p className="text-2xl font-bold text-green-300">{score}</p>
      </div>
    </div>
  );
};
