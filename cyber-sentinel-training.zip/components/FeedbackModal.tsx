
import React from 'react';
import type { Feedback } from '../types';

interface FeedbackModalProps {
  feedback: Feedback;
  onNext: () => void;
}

const CheckIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const XIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ feedback, onNext }) => {
  const { isCorrect, explanation } = feedback;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className={`bg-gray-800 rounded-lg shadow-2xl w-full max-w-2xl border-t-8 ${isCorrect ? 'border-green-500' : 'border-red-500'}`}>
        <div className="p-8">
            <div className="flex flex-col items-center text-center">
                {isCorrect ? <CheckIcon /> : <XIcon />}
                <h2 className={`mt-4 text-4xl font-bold font-orbitron ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                    {isCorrect ? 'Access Granted' : 'Threat Detected'}
                </h2>
            </div>
            <div className="mt-6 text-gray-300 text-left bg-black/30 p-4 rounded-md border border-gray-700 max-h-60 overflow-y-auto">
                <h3 className="font-bold text-lg mb-2 text-cyan-400">Debrief:</h3>
                <p className="leading-relaxed">{explanation}</p>
            </div>
            <div className="mt-8 text-center">
                <button
                onClick={onNext}
                className="bg-cyan-500 hover:bg-cyan-400 text-gray-900 font-bold py-3 px-10 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/30"
                >
                Continue
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
