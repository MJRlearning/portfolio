
import React from 'react';
import type { Mission } from '../types';
import { LoadingSpinner } from './LoadingSpinner';

interface MissionControlProps {
  mission: Mission | null;
  onAnswer: (selectedIndex: number) => void;
  isLoading: boolean;
  isAnswered: boolean;
}

export const MissionControl: React.FC<MissionControlProps> = ({ mission, onAnswer, isLoading, isAnswered }) => {
  if (isLoading || !mission) {
    return (
      <div className="flex flex-col items-center justify-center bg-gray-800/50 backdrop-blur-sm border border-cyan-700 rounded-lg p-8 shadow-lg min-h-[400px]">
        <LoadingSpinner />
        <p className="mt-4 text-cyan-300 animate-pulse">Generating Mission Scenario...</p>
      </div>
    );
  }

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-cyan-700 rounded-lg p-6 md:p-8 shadow-2xl shadow-cyan-500/10">
      <div className="mb-6">
        <h2 className="text-lg font-bold text-cyan-400 mb-2 font-orbitron tracking-wide">SCENARIO_</h2>
        <div className="bg-black/40 p-4 rounded-md border border-gray-700">
          <p className="text-gray-200 leading-relaxed">{mission.scenario}</p>
        </div>
      </div>
      
      <div className="mb-8">
        <h2 className="text-lg font-bold text-cyan-400 mb-2 font-orbitron tracking-wide">DIRECTIVE_</h2>
        <p className="text-xl text-gray-100">{mission.question}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {mission.options.map((option, index) => {
          const isCorrect = index === mission.correctAnswerIndex;
          const buttonStyle = isAnswered
            ? isCorrect
              ? 'bg-green-700 border-green-500 ring-2 ring-green-400'
              : 'bg-red-800 border-red-600 opacity-60'
            : 'bg-gray-700 hover:bg-cyan-800 border-gray-600 hover:border-cyan-500';

          return (
            <button
              key={index}
              onClick={() => onAnswer(index)}
              disabled={isAnswered}
              className={`p-4 rounded-lg border text-left transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed ${buttonStyle}`}
            >
              <span className="font-bold mr-2 text-cyan-300">{String.fromCharCode(65 + index)}.</span>
              {option}
            </button>
          );
        })}
      </div>
    </div>
  );
};
