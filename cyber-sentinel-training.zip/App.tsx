
import React, { useState, useCallback, useEffect } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { MissionControl } from './components/MissionControl';
import { FeedbackModal } from './components/FeedbackModal';
import { ScoreDisplay } from './components/ScoreDisplay';
import { generateMission } from './services/geminiService';
import { CYBERSECURITY_TOPICS } from './constants';
import type { Mission, Feedback } from './types';

type GameState = 'welcome' | 'playing' | 'finished';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>('welcome');
  const [currentMissionIndex, setCurrentMissionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [currentMission, setCurrentMission] = useState<Mission | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  const fetchNextMission = useCallback(async (missionIndex: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const topic = CYBERSECURITY_TOPICS[missionIndex];
      const missionData = await generateMission(topic);
      setCurrentMission(missionData);
    } catch (err) {
      setError('Failed to generate mission. The sentinel network might be down. Please try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleStartGame = () => {
    setCurrentMissionIndex(0);
    setScore(0);
    setGameState('playing');
    fetchNextMission(0);
  };

  const handleAnswerSubmit = (selectedIndex: number) => {
    if (!currentMission) return;

    const isCorrect = selectedIndex === currentMission.correctAnswerIndex;
    if (isCorrect) {
      setScore(prevScore => prevScore + 10);
    }
    setFeedback({
      isCorrect,
      explanation: currentMission.explanation,
    });
  };
  
  const handleNextMission = () => {
    setFeedback(null);
    const nextIndex = currentMissionIndex + 1;
    if (nextIndex < CYBERSECURITY_TOPICS.length) {
      setCurrentMissionIndex(nextIndex);
      fetchNextMission(nextIndex);
    } else {
      setGameState('finished');
    }
  };

  const renderGameState = () => {
    switch (gameState) {
      case 'playing':
        return (
          <div className="w-full max-w-4xl mx-auto p-4 md:p-6">
            <ScoreDisplay score={score} currentMission={currentMissionIndex + 1} totalMissions={CYBERSECURITY_TOPICS.length} />
            {error && <div className="bg-red-900 border border-red-500 text-red-200 px-4 py-3 rounded-lg relative my-4 text-center">{error}</div>}
            <MissionControl
              mission={currentMission}
              onAnswer={handleAnswerSubmit}
              isLoading={isLoading}
              isAnswered={feedback !== null}
            />
          </div>
        );
      case 'finished':
          return (
            <div className="flex flex-col items-center justify-center text-center p-8">
              <h1 className="text-4xl md:text-5xl font-bold font-orbitron text-cyan-400 mb-4">Training Complete!</h1>
              <p className="text-lg md:text-xl text-gray-300 mb-6">You've successfully navigated the Cyber Sentinel challenges.</p>
              <div className="bg-gray-800 border-2 border-cyan-500 rounded-lg p-6 shadow-lg shadow-cyan-500/20">
                <p className="text-2xl text-gray-200">Final Score:</p>
                <p className="text-6xl font-bold text-green-400 my-2">{score}</p>
                <p className="text-lg text-gray-400">You are now better equipped to defend the digital realm.</p>
              </div>
              <button
                onClick={handleStartGame}
                className="mt-8 bg-cyan-500 hover:bg-cyan-400 text-gray-900 font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg shadow-cyan-500/30"
              >
                Restart Training
              </button>
            </div>
          );
      case 'welcome':
      default:
        return <WelcomeScreen onStart={handleStartGame} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 bg-gradient-to-br from-gray-900 via-gray-900 to-blue-900/50 flex flex-col items-center justify-center p-4 selection:bg-cyan-500 selection:text-black">
      {renderGameState()}
      {feedback && <FeedbackModal feedback={feedback} onNext={handleNextMission} />}
    </div>
  );
};

export default App;
