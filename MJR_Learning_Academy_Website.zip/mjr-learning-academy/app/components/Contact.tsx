
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Mail, MessageCircle, Download, Users } from 'lucide-react'

const Contact = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="contact" className="py-20 bg-mjr-light">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Stay Connected
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get our free AI tools guide and stay updated with educational insights and professional development resources
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
          {/* Newsletter Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-6">
                What You'll Receive
              </h3>
              
              <div className="space-y-6">
                {[
                  {
                    icon: Download,
                    title: 'Free AI Tools Guide',
                    description: 'A practical introduction to AI tools for education professionals with implementation guidance.'
                  },
                  {
                    icon: Mail,
                    title: 'Educational Insights',
                    description: 'Regular updates on educational technology trends and professional development opportunities.'
                  },
                  {
                    icon: MessageCircle,
                    title: 'Professional Resources',
                    description: 'Access to guides, tips, and resources for modern educational practice.'
                  }
                ].map((benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    animate={inView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
                    className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-lg"
                  >
                    <div className="p-3 bg-mjr-red text-white rounded-lg flex-shrink-0">
                      <benefit.icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-montserrat font-semibold text-mjr-dark mb-2">
                        {benefit.title}
                      </h4>
                      <p className="text-gray-700">
                        {benefit.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Professional credentials */}
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <h4 className="text-xl font-montserrat font-bold text-mjr-dark mb-4 text-center">
                Professional Background
              </h4>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-mjr-red">25+</div>
                  <div className="text-sm text-gray-600">Years Experience</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-mjr-red">NHS</div>
                  <div className="text-sm text-gray-600">Training Specialist</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Newsletter Signup */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-white p-8 rounded-2xl shadow-lg"
          >
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-mjr-red text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <Download className="w-10 h-10" />
              </div>
              <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-4">
                Download Free Guide
              </h3>
              <p className="text-gray-600">
                Subscribe to receive our AI tools guide and educational insights
              </p>
            </div>

            {/* Substack Embed Frame */}
            <div className="bg-mjr-light p-6 rounded-xl mb-6">
              <iframe
                src="https://markrollins1.substack.com/embed"
                width="100%"
                height="320"
                style={{ border: 'none', backgroundColor: 'transparent' }}
                frameBorder="0"
                scrolling="no"
                title="Subscribe to MJR Learning Academy Newsletter"
                className="w-full"
              ></iframe>
            </div>

            {/* Simple footer */}
            <div className="space-y-4">
              <p className="text-xs text-gray-500 text-center">
                Professional development content for educators. Unsubscribe anytime.
              </p>
            </div>

            {/* Connect directly */}
            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
              <p className="text-gray-600 mb-4">
                Connect with us:
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://markrollins1.substack.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-mjr-red hover:text-red-700 font-medium transition-colors duration-300 flex items-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  Newsletter
                </a>
                <span className="text-gray-300">|</span>
                <a
                  href="https://mjrlearning.podbean.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-mjr-red hover:text-red-700 font-medium transition-colors duration-300 flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Podcast
                </a>
                <span className="text-gray-300">|</span>
                <a
                  href="https://patreon.com/MJRAiLearningAcademy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-mjr-red hover:text-red-700 font-medium transition-colors duration-300 flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  Community
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

export default Contact
