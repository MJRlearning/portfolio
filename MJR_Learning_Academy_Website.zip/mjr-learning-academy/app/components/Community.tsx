
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Users, MessageCircle, BookOpen, Zap, Star, Gift, Clock, Shield } from 'lucide-react'

const Community = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const benefits = [
    {
      icon: MessageCircle,
      title: 'Exclusive Community Access',
      description: 'Connect with like-minded educators and share AI implementation experiences',
      highlight: 'Network with 500+ educators'
    },
    {
      icon: BookOpen,
      title: 'Premium Content Library',
      description: 'Access to advanced AI tutorials, case studies, and implementation guides',
      highlight: '50+ exclusive resources'
    },
    {
      icon: Zap,
      title: 'Early Access to New Tools',
      description: 'Be the first to discover and test the latest AI tools for education',
      highlight: 'Tools worth £200+ monthly'
    },
    {
      icon: Gift,
      title: 'Monthly Live Q&A Sessions',
      description: 'Direct access to Mark Rollins for personalised advice and guidance',
      highlight: 'Value: £50 per session'
    }
  ]

  const tiers = [
    {
      name: 'Supporter',
      price: '£5',
      period: '/month',
      description: 'Perfect for educators starting their AI journey',
      features: [
        'Community access',
        'Basic tutorial library',
        'Monthly newsletter',
        'Tool recommendations'
      ],
      popular: false,
      cta: 'Start Supporting'
    },
    {
      name: 'Educator Pro',
      price: '£15',
      period: '/month',
      description: 'Ideal for serious educators wanting to excel',
      features: [
        'Everything in Supporter',
        'Advanced tutorials',
        'Live Q&A sessions',
        'Early tool access',
        'Implementation worksheets',
        'Priority support'
      ],
      popular: true,
      cta: 'Go Pro Today'
    },
    {
      name: 'Institution',
      price: '£50',
      period: '/month',
      description: 'For schools and organizations',
      features: [
        'Everything in Educator Pro',
        'Team accounts (up to 10)',
        'Custom training sessions',
        'Implementation consulting',
        'White-label resources',
        'Dedicated support'
      ],
      popular: false,
      cta: 'Contact for Setup'
    }
  ]

  const testimonials = [
    {
      name: "Rachel Green",
      role: "Primary Teacher",
      content: "The Patreon community has been invaluable. The monthly Q&A sessions helped me implement AI tools successfully in my Year 3 classroom.",
      rating: 5
    },
    {
      name: "David Kumar",
      role: "Secondary Head",
      content: "Our school joined the Institution tier and the custom training was exceptional. Staff adoption of AI tools increased by 80%.",
      rating: 5
    }
  ]

  return (
    <section id="community" className="py-20 bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Join Our <span className="text-mjr-red">Exclusive Community</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connect with educators worldwide, access premium resources, and get personalised support 
            for your AI implementation journey
          </p>
        </motion.div>

        {/* Benefits */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center"
            >
              <div className="w-16 h-16 bg-mjr-red text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <benefit.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-montserrat font-bold text-mjr-dark mb-3">
                {benefit.title}
              </h3>
              <p className="text-gray-600 mb-3">
                {benefit.description}
              </p>
              <div className="bg-mjr-light px-3 py-1 rounded-full">
                <span className="text-mjr-red font-semibold text-sm">{benefit.highlight}</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Pricing Tiers */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-16"
        >
          <h3 className="text-3xl font-montserrat font-bold text-center text-mjr-dark mb-12">
            Choose Your Community Level
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            {tiers.map((tier, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                className={`relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 ${
                  tier.popular ? 'ring-2 ring-mjr-red scale-105' : ''
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-mjr-red text-white px-4 py-2 rounded-full text-sm font-bold">
                      Most Popular
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h4 className="text-2xl font-montserrat font-bold text-mjr-dark mb-2">
                    {tier.name}
                  </h4>
                  <div className="flex items-baseline justify-center mb-4">
                    <span className="text-4xl font-montserrat font-bold text-mjr-red">
                      {tier.price}
                    </span>
                    <span className="text-gray-600 ml-1">{tier.period}</span>
                  </div>
                  <p className="text-gray-600">{tier.description}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <div className="w-5 h-5 bg-green-500 text-white rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-xs">✓</span>
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href="https://patreon.com/MJRAiLearningAcademy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-3 rounded-lg font-montserrat font-bold transition-all duration-300 text-center block ${
                    tier.popular
                      ? 'bg-mjr-red text-white hover:bg-red-700 shadow-lg hover:shadow-xl'
                      : 'bg-gray-100 text-mjr-dark hover:bg-gray-200'
                  }`}
                >
                  {tier.cta}
                </a>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-8">
            <p className="text-gray-600 mb-4">
              All plans include access to our growing library of AI education resources
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-green-500" />
                <span>Cancel Anytime</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-green-500" />
                <span>7-Day Free Trial</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-green-500" />
                <span>Exclusive Content</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Community Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="bg-white rounded-2xl p-8 shadow-lg"
        >
          <h3 className="text-3xl font-montserrat font-bold text-center text-mjr-dark mb-8">
            What Community Members Say
          </h3>
          
          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 italic mb-4">
                  "{testimonial.content}"
                </p>
                <div>
                  <p className="font-montserrat font-bold text-mjr-dark">{testimonial.name}</p>
                  <p className="text-gray-600 text-sm">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Final CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
          className="text-center mt-16"
        >
          <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-4">
            Ready to Transform Your Teaching?
          </h3>
          <p className="text-xl text-gray-600 mb-8">
            Start with our free guide, then join the community when you're ready for more
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => {
                const element = document.getElementById('lead-magnet')
                element?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="btn-primary inline-flex items-center gap-2 text-lg px-8 py-4"
            >
              <Gift className="w-5 h-5" />
              Get Free Guide First
            </button>
            <a
              href="https://patreon.com/MJRAiLearningAcademy"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary text-lg px-8 py-4 inline-flex items-center gap-2"
            >
              <Users className="w-5 h-5" />
              Join Community
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Community
