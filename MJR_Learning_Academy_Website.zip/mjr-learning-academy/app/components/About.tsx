
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { GraduationCap, Users, Award, Target } from 'lucide-react'
import Image from 'next/image'

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const stats = [
    { number: '25+', label: 'Years Experience', icon: Award },
    { number: '1000+', label: 'Students Taught', icon: Users },
    { number: '50+', label: 'Courses Created', icon: GraduationCap },
    { number: '100%', label: 'Dedicated to Excellence', icon: Target },
  ]

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Meet <span className="text-mjr-red">Mark Rollins</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            CEO & Founder bringing 25+ years of expertise in education, eLearning development across multiple sectors, and instructional design
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-[4/5] bg-mjr-light rounded-2xl overflow-hidden shadow-2xl relative">
              <Image
                src="/images/profile-mark-rollins.png"
                alt="Mark Rollins - Education Expert and CEO of MJR Learning Academy"
                fill
                className="object-cover"
                priority
              />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-6"
          >
            <div className="space-y-4">
              <h3 className="text-2xl font-montserrat font-bold text-mjr-dark">
                M.Sc, B.Sc, Cert Ed., PG Dip eLearning
              </h3>
              
              <p className="text-lg text-gray-700 leading-relaxed">
                Mark believes that <strong className="text-mjr-red">"AI shouldn't replace teachers—it should support them."</strong> 
                Every course he creates is built with this philosophy at its core.
              </p>

              <p className="text-gray-700 leading-relaxed">
                With over 25 years of experience spanning education, eLearning development across Corporate, Academic, Apprenticeship, and Healthcare sectors, 
                Mark is uniquely positioned at the intersection of traditional pedagogy and cutting-edge AI technology.
              </p>

              <p className="text-gray-700 leading-relaxed">
                His mission through MJR Learning Academy is to democratize access to AI in education and training, 
                providing high-impact online learning that helps professionals understand, adapt to, and lead with technology.
              </p>

              <div className="bg-mjr-light p-6 rounded-xl">
                <h4 className="font-montserrat font-semibold text-mjr-dark mb-3">Educational Approach</h4>
                <p className="text-gray-700">
                  Mark integrates evidence-based pedagogy with proven frameworks including Gagné's Nine Events, 
                  PSI, and Bloom's Taxonomy, enhanced with practical AI tools like ChatGPT, Gemini, and Synthesia.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <span className="bg-mjr-red text-white px-4 py-2 rounded-full text-sm font-medium">
                25+ Years Experience
              </span>
              <span className="bg-mjr-red text-white px-4 py-2 rounded-full text-sm font-medium">
                AI in Education Expert
              </span>
              <span className="bg-mjr-red text-white px-4 py-2 rounded-full text-sm font-medium">
                Multi-Sector eLearning Expert
              </span>
            </div>
          </motion.div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
              className="text-center p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <stat.icon className="w-12 h-12 text-mjr-red mx-auto mb-4" />
              <div className="text-3xl font-montserrat font-bold text-mjr-dark mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 font-opensans">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export default About
