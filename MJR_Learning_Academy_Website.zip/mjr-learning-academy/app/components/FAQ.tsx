
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { useState } from 'react'
import { ChevronDown, ChevronUp, HelpCircle, CheckCircle, Clock, Shield } from 'lucide-react'

const FAQ = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const faqs = [
    {
      question: "What AI tools are covered in your resources?",
      answer: "Our guide introduces practical AI tools for educators including ChatGPT for content creation, Canva for visual design, Grammarly for writing assistance, and other commonly used educational technologies. Each tool is presented with clear implementation guidance.",
      icon: CheckCircle,
      category: "Content"
    },
    {
      question: "Are these resources suitable for all educational levels?",
      answer: "Yes, the principles and tools covered can be adapted for various educational contexts, from primary education through higher education and professional training. The approaches are flexible and can be tailored to specific needs.",
      icon: CheckCircle,
      category: "Compatibility"
    },
    {
      question: "Do I need technical expertise to implement these tools?",
      answer: "No specialised technical knowledge is required. Our resources focus on user-friendly tools and provide step-by-step guidance that any educator can follow. The emphasis is on practical application rather than technical complexity.",
      icon: HelpCircle,
      category: "Technical"
    },
    {
      question: "What's included in the free guide?",
      answer: "The guide provides an introduction to key AI tools for education, including practical examples and implementation strategies. It's designed to help educators understand how these tools can be integrated into their professional practice.",
      icon: CheckCircle,
      category: "Resources"
    },
    {
      question: "How can I access additional resources?",
      answer: "Beyond the free guide, we offer structured courses through our learning platform. These provide more comprehensive coverage of educational technology topics and professional development opportunities.",
      icon: CheckCircle,
      category: "Access"
    },
    {
      question: "Are there resources specific to healthcare education?",
      answer: "Yes, we offer specialised content for NHS and healthcare professionals, including training on specific systems and eLearning development for healthcare contexts. This reflects Mark's experience in NHS training development.",
      icon: HelpCircle,
      category: "Healthcare"
    }
  ]

  return (
    <section id="faq" className="py-20 bg-mjr-light">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Frequently Asked <span className="text-mjr-red">Questions</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Common questions about our educational resources and professional development offerings
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                >
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-mjr-red text-white rounded-lg">
                      <faq.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-lg font-montserrat font-semibold text-mjr-dark">
                        {faq.question}
                      </h3>
                      <p className="text-sm text-mjr-red font-medium">
                        {faq.category}
                      </p>
                    </div>
                  </div>
                  <div className="flex-shrink-0 ml-4">
                    {openIndex === index ? (
                      <ChevronUp className="w-6 h-6 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                </button>
                
                <motion.div
                  initial={false}
                  animate={{ 
                    height: openIndex === index ? 'auto' : 0,
                    opacity: openIndex === index ? 1 : 0
                  }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-8 pb-6">
                    <div className="pl-12">
                      <p className="text-gray-700 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Additional questions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center mt-16 bg-white rounded-2xl p-8 shadow-lg"
        >
          <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-4">
            Have Additional Questions?
          </h3>
          <p className="text-xl text-gray-600 mb-8">
            Explore our resources or reach out for more information about our educational offerings
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => {
                const element = document.getElementById('offerings')
                element?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="btn-primary inline-flex items-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Explore Resources
            </button>
            <button
              onClick={() => {
                const element = document.getElementById('contact')
                element?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="btn-secondary"
            >
              Get in Touch
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default FAQ
