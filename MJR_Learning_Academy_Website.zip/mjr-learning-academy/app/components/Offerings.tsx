
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { BookOpen, Headphones, Mail, Heart, ArrowRight, Star, Shield, Users, Clock, Bot } from 'lucide-react'

const Offerings = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const offerings = [
    {
      icon: Heart,
      title: 'eLearning Solutions',
      description: 'Comprehensive training and consultation across Corporate, Academic, Apprenticeship, and Healthcare sectors for learning systems and educational design.',
      link: 'http://mjrlearning.co.uk',
      features: ['Multi-Sector Expertise', 'Custom Development', 'Professional Training', 'Implementation Support'],
      color: 'bg-red-50 hover:bg-red-100',
      iconColor: 'text-red-600',
      cta: 'Explore Services'
    },
    {
      icon: BookOpen,
      title: 'Online Courses',
      description: 'Professional development courses covering AI applications in education, instructional design, and modern teaching methodologies.',
      link: 'https://mjr-learning-academy.getlearnworlds.com',
      features: ['Structured Learning', 'Evidence-Based Content', 'Interactive Format', 'Professional Guidance'],
      color: 'bg-blue-50 hover:bg-blue-100',
      iconColor: 'text-blue-600',
      cta: 'View Courses'
    },
    {
      icon: Headphones,
      title: 'MJR Learning Podcast',
      description: 'Regular discussions on education technology, professional development, and teaching innovation.',
      link: 'https://mjrlearning.podbean.com',
      features: ['Expert Conversations', 'Practical Insights', 'Industry Perspectives', 'Regular Episodes'],
      color: 'bg-purple-50 hover:bg-purple-100',
      iconColor: 'text-purple-600',
      cta: 'Listen Now'
    },
    {
      icon: Bot,
      title: 'AI Avatar Assistant',
      description: 'Interact with my AI-powered avatar for personalised guidance, educational support, and instant answers.',
      link: 'https://studio.d-id.com/agents/share?id=agt_kbxZy-xX&utm_source=copy&key=WjI5dlkyeGxNVzloZFhSb01ud3hNVE16TVRVNE16VTRNakUxTURRMk16QXdNamM2TUd4RVdsTjZhalZZT1d0bVZHWlRlVEJpYVhwUw==',
      features: ['24/7 Availability', 'Personalised Responses', 'Educational Guidance', 'Instant Support'],
      color: 'bg-indigo-50 hover:bg-indigo-100',
      iconColor: 'text-indigo-600',
      cta: 'Chat with AI Avatar'
    },
    {
      icon: Mail,
      title: 'Newsletter',
      description: 'Educational insights, tool reviews, and professional development content delivered regularly.',
      link: 'https://markrollins1.substack.com',
      features: ['Regular Updates', 'Tool Evaluations', 'Implementation Ideas', 'Professional Resources'],
      color: 'bg-green-50 hover:bg-green-100',
      iconColor: 'text-green-600',
      cta: 'Subscribe'
    },
  ]

  const trustIndicators = [
    { icon: Users, value: 'Professional', label: 'Education Focus' },
    { icon: BookOpen, value: 'Practical', label: 'Implementation' },
    { icon: Shield, value: 'Quality', label: 'Resources' },
    { icon: Clock, value: '25+', label: 'Years Experience' }
  ]

  return (
    <section id="offerings" className="py-20 bg-mjr-light">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Educational <span className="text-mjr-red">Resources & Training</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional development resources for educators interested in modern teaching technologies and methodologies
          </p>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16"
        >
          {trustIndicators.map((indicator, index) => (
            <div key={index} className="text-center p-4 bg-white rounded-xl shadow-lg">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-mjr-red text-white rounded-full mb-3">
                <indicator.icon className="w-6 h-6" />
              </div>
              <div className="text-2xl font-montserrat font-bold text-mjr-dark mb-1">
                {indicator.value}
              </div>
              <div className="text-gray-600 text-sm">
                {indicator.label}
              </div>
            </div>
          ))}
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {offerings.map((offering, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={`group ${offering.color} rounded-2xl p-8 transition-all duration-300 hover:shadow-xl cursor-pointer relative overflow-hidden`}
              onClick={() => {
                window.open(offering.link, '_blank');
              }}
            >
              <div className="flex items-center mb-6">
                <div className={`p-4 ${offering.iconColor} bg-white rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <offering.icon className="w-8 h-8" />
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="text-2xl font-montserrat font-bold text-mjr-dark group-hover:text-mjr-red transition-colors duration-300">
                    {offering.title}
                  </h3>
                </div>
                <ArrowRight className="w-6 h-6 text-gray-400 group-hover:text-mjr-red group-hover:translate-x-1 transition-all duration-300" />
              </div>

              <p className="text-gray-700 mb-6 leading-relaxed">
                {offering.description}
              </p>

              <div className="space-y-2 mb-8">
                {offering.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center text-sm text-gray-600">
                    <div className="w-2 h-2 bg-mjr-red rounded-full mr-3"></div>
                    {feature}
                  </div>
                ))}
              </div>

              <div className="pt-6 border-t border-gray-200">
                <button className="w-full bg-mjr-red text-white py-3 rounded-lg font-montserrat font-bold hover:bg-red-700 transition-colors duration-300 group-hover:shadow-lg">
                  {offering.cta} →
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-16 bg-white rounded-2xl p-8 shadow-lg"
        >
          <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-4">
            Explore Our Resources
          </h3>
          <p className="text-xl text-gray-600 mb-8">
            Start with our free guide or explore our professional development offerings
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => {
                const element = document.getElementById('lead-magnet')
                element?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="btn-primary inline-flex items-center gap-2 text-lg px-8 py-4"
            >
              <BookOpen className="w-5 h-5" />
              View Free Guide
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => {
                const element = document.getElementById('contact')
                element?.scrollIntoView({ behavior: 'smooth' })
              }}
              className="btn-secondary text-lg px-8 py-4"
            >
              Get in Touch
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Offerings
