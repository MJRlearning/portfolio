
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Star, Quote } from 'lucide-react'

const Testimonials = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "High School Science Teacher",
      content: "Mark's practical approach to AI tools has been helpful for lesson planning. The resources are well-structured and easy to implement.",
      rating: 5
    },
    {
      name: "Dr. Michael Chen",
      role: "NHS Training Coordinator",
      content: "The NHS eLearning development course provided valuable insights into instructional design and system integration.",
      rating: 5
    },
    {
      name: "Emma Williams",
      role: "Primary School Head Teacher",
      content: "Mark's podcast offers practical perspectives on education technology. The content is relevant and professionally presented.",
      rating: 4
    }
  ]

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6">
            Professional <span className="text-mjr-red">Feedback</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Insights from education professionals who have engaged with our resources
          </p>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100"
            >
              <div className="mb-6">
                <h4 className="font-montserrat font-bold text-mjr-dark text-lg mb-1">
                  {testimonial.name}
                </h4>
                <p className="text-gray-600 text-sm">{testimonial.role}</p>
              </div>

              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>

              <div className="relative">
                <Quote className="w-6 h-6 text-mjr-red opacity-50 absolute -top-2 -left-2" />
                <p className="text-gray-700 pl-4 leading-relaxed">
                  "{testimonial.content}"
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Testimonials
