
'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { ArrowRight, CheckCircle, BookOpen } from 'lucide-react'

const LeadMagnet = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const openPatreon = () => {
    window.open('https://patreon.com/MJRAiLearningAcademy', '_blank')
  }

  const guideFeatures = [
    'Practical AI tool introductions',
    'Step-by-step implementation guides',
    'Educational use case examples',
    'Free access to all resources'
  ]

  return (
    <section id="lead-magnet" className="py-20 bg-mjr-light">
      <div className="container-max section-padding">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl md:text-5xl font-montserrat font-bold text-mjr-dark mb-6"
          >
            Free Resources: <span className="text-mjr-red">AI Tools & Guides</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto"
          >
            Access our comprehensive collection of AI tools guides, resources, and educational content 
            on our Patreon page - all available for free.
          </motion.p>

          <div className="grid lg:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
            {/* Guide Preview */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative"
            >
              <div className="aspect-[3/4] bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-mjr-red text-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-montserrat font-bold text-mjr-dark mb-2">
                    AI Tools for Educators
                  </h3>
                  <p className="text-gray-600">
                    Professional guides and resources available on Patreon
                  </p>
                </div>
                
                <div className="space-y-4">
                  {guideFeatures.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Content & CTA */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-left space-y-6"
            >
              <h3 className="text-3xl font-montserrat font-bold text-mjr-dark mb-6">
                What's Available on Patreon
              </h3>

              <div className="space-y-4">
                {[
                  'Comprehensive AI tools guides for education',
                  'Step-by-step implementation strategies',
                  'Real-world classroom examples and case studies',
                  'Regular updates and new resource additions'
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={inView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
                    className="flex items-start gap-4"
                  >
                    <div className="w-8 h-8 bg-mjr-light rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-bold text-mjr-red">{index + 1}</span>
                    </div>
                    <p className="text-lg text-gray-700">{item}</p>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 1.0 }}
                className="pt-8"
              >
                <button
                  onClick={openPatreon}
                  className="w-full bg-mjr-red hover:bg-red-700 text-white px-8 py-4 rounded-xl font-montserrat font-bold text-lg transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center gap-3 group"
                >
                  <BookOpen className="w-5 h-5" />
                  View Free Guide
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <div className="mt-4 text-center">
                  <p className="text-gray-600 text-sm">
                    Free to access • No subscription required
                  </p>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default LeadMagnet
