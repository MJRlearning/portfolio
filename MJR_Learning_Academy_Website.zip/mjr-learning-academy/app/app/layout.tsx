
import type { Metadata } from 'next'
import { Montserrat, Open_Sans } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '../components/theme-provider'

const montserrat = Montserrat({
  subsets: ['latin'],
  variable: '--font-montserrat',
  display: 'swap',
})

const openSans = Open_Sans({
  subsets: ['latin'],
  variable: '--font-opensans',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'MJR Learning Academy - AI-Powered Education Training',
  description: 'Transform your teaching with AI. Expert courses, tools, and resources for educators from Mark Rollins. Join 1,000+ educators revolutionizing education with AI.',
  keywords: 'AI education, teacher training, educational technology, NHS eLearning, AI tools for teachers, instructional design, EdTech, artificial intelligence in education',
  authors: [{ name: 'Mark Rollins', url: 'https://mjr-learning-academy.com' }],
  creator: 'Mark Rollins',
  publisher: 'MJR Learning Academy',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://mjr-learning-academy.com'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: 'https://mjr-learning-academy.com',
    title: 'MJR Learning Academy - AI-Powered Education Training',
    description: 'Transform your teaching with AI. Expert courses, tools, and resources for educators from Mark Rollins. Join 1,000+ educators revolutionizing education with AI.',
    siteName: 'MJR Learning Academy',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'MJR Learning Academy - AI-Powered Education Training',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MJR Learning Academy - AI-Powered Education Training',
    description: 'Transform your teaching with AI. Expert courses, tools, and resources for educators from Mark Rollins.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'google-site-verification-token',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${montserrat.variable} ${openSans.variable}`}>
      <head>
        {/* Google Analytics */}
        <script
          async
          src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'GA_MEASUREMENT_ID', {
                page_title: 'MJR Learning Academy',
                page_location: window.location.href,
              });
            `,
          }}
        />
        
        {/* Hotjar Tracking */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function(h,o,t,j,a,r){
                  h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
                  h._hjSettings={hjid:3586789,hjsv:6};
                  a=o.getElementsByTagName('head')[0];
                  r=o.createElement('script');r.async=1;
                  r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
                  a.appendChild(r);
              })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
            `,
          }}
        />

        {/* Conversion Tracking */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              function trackConversion(event_name, value) {
                if (typeof gtag !== 'undefined') {
                  gtag('event', event_name, {
                    event_category: 'conversion',
                    event_label: 'lead_generation',
                    value: value || 0
                  });
                }
              }
              
              // Track lead magnet downloads
              function trackLeadMagnetDownload() {
                trackConversion('lead_magnet_download', 25);
              }
              
              // Track newsletter signups
              function trackNewsletterSignup() {
                trackConversion('newsletter_signup', 15);
              }
              
              // Track course clicks
              function trackCourseClick() {
                trackConversion('course_click', 10);
              }
            `,
          }}
        />

        {/* Schema.org JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'EducationalOrganization',
              name: 'MJR Learning Academy',
              description: 'AI-powered education training for teachers and NHS professionals',
              url: 'https://mjr-learning-academy.com',
              founder: {
                '@type': 'Person',
                name: 'Mark Rollins',
                jobTitle: 'Educational Technology Expert',
                knowsAbout: ['Artificial Intelligence in Education', 'NHS eLearning', 'Instructional Design'],
              },
              address: {
                '@type': 'PostalAddress',
                addressCountry: 'GB',
              },
              contactPoint: {
                '@type': 'ContactPoint',
                contactType: 'customer service',
                email: 'contact@mjr-learning-academy.com',
              },
              sameAs: [
                'https://markrollins1.substack.com',
                'https://mjrlearning.podbean.com',
                'https://patreon.com/MJRAiLearningAcademy',
              ],
            }),
          }}
        />
      </head>
      <body className={`${montserrat.variable} ${openSans.variable} antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
